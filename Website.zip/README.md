
# Algerian Treasures Export

This website is designed for GitHub Pages.

## ✅ How to publish

1. Create a GitHub repository named `algerian-treasures-export`
2. Upload all the contents of this folder.
3. Go to **Settings > Pages**
4. Under **Source**, select `main` branch and root `/`
5. Click **Save** – your site will be live at `https://yourusername.github.io/algerian-treasures-export/`

Enjoy!
